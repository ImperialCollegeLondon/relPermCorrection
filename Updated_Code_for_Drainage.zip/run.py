import pandas as pd
import numpy as np
import multiprocessing
from joblib import Parallel, delayed


from scipy.signal import savgol_filter
from scipy import stats
import matplotlib.pyplot as plt
from scipy.optimize import minimize,shgo,dual_annealing,differential_evolution,basinhopping
from scipy.interpolate import CubicSpline,interp1d,Akima1DInterpolator,PchipInterpolator


class MyBounds(object):
    ''' 
    bounds class to make sure your variable is with in the expected bounds
    '''
    def __init__(self, xmin, xmax):
        self.xmax = np.array(xmax)
        self.xmin = np.array(xmin)

    def __call__(self, **kwargs):
        x = kwargs["x_new"]
        tmax = bool(np.all(x <= self.xmax))
        tmin = bool(np.all(x >= self.xmin))
        return tmax and tmin

# Bounds:
lower_bounds = [  0,   0,    0,    0,   0,    0]
upper_bounds = [  1,   1,    1,    1,   1,    1]
my_bounds    = MyBounds(lower_bounds, upper_bounds)


#'''
# Sample length:
L = 0.02         				# m 
Delta_x = 3.6e-6   				# m
LNew = L           
#'''



consider_fw=np.array([True,True,True,True,True,True])
#'''

# CO2 Density:
rhoOil = 600        	 # kg/m3

# CO2 viscosity:
muOil = 0.00002     	 # Pa.s

muOil = 0.00002     	 # Pa.s

# Water Density:
rhoWater = 1218.55  	 # kg/m3

# Water Viscosity:
muWater = 0.0006   	 # Pa.s

# gravitational acceleration:
g = 9.8             	 # m/s2
IncludeGravity = 0;#1
# Permeability:
K = 1.18E-12        	 # m2
K =  1.030308448268e-12# m2

# Total Flow Rate:
qt = 5.9E-05 # m/s

# Water Fractional Flow:
fw = np.array([1.0,	0.9,	0.7,	0.5,	0.2,	0.05,	0])
fw = fw[::-1]
fw = fw[:-1]
fw = fw[consider_fw]
Nfw = len(fw)-1



# Inlet Capillary Pressure:
Pc = 000.0*np.array([3.19584815802796,2.56498909270457,2.54267145726145,2.38963891737797,2.30075413611575,2.373854099684]) #Pa WW (NBF)

PcInlet  = 0.0*Pc[consider_fw]
PcOutlet = 0.0*Pc[consider_fw]
# Pressure Difference:

#DeltaP = 1.00*np.array([3500.0,	   4600.0,	10250.0,	7990.0,	5150.0,	3150.0,	1800.0])# Pa
DeltaP = 1000.00*np.array([0.69  , 0.75  ,  1.12 ,  1.46 ,  1.24 ,  1.01 ,0.89]) # Pa

#DeltaP = 1000*np.array([1.75, 6.51, 7.27, 8.65, 9.42, 10.8, 5.94])
DeltaP = DeltaP[::-1]
DeltaP = DeltaP[:-1]
DeltaP =DeltaP[consider_fw]
DeltaP /=L

print(qt*fw*muWater/K/DeltaP)
aaa = qt*(1-fw)*muOil/K/DeltaP

#print(aaa)
#exit()

# Average Saturation:
SWEXP = np.array([1.00E+00,	9.95E-01,	9.21E-01,	7.80E-01,	6.56E-01,	6.07E-01,	4.32E-01])
SWEXP = SWEXP[::-1]
SWEXP = SWEXP[:-1]
SWEXP =SWEXP[consider_fw]



# Saturtion Profile:
a = (pd.read_excel('WWBen_newSw2.xlsx'))
Sws = 1.0-a.to_numpy()
Sws = Sws[:,::-1]
Sws = Sws[:,:-1]
Sws = Sws[:,consider_fw[:]]
'''
for i, Swj in enumerate(SWEXP):
    Sws[:, i] = Swj
'''
########################################################################

SWEXP[:] = np.min(Sws,axis=0)
SWEXPMean = np.mean(Sws,axis=0)

Swi = 2.50E-01
SoR = 0.0


#'''
SWEXP[0] = Swi-1e-16
SWEXP[-1] = 1.0 - SoR
SWEXP = np.linspace(SWEXP[0], SWEXP[-1], num=len(SWEXP)+1)

#'''
# Average Relative Error in Pressure Difference for Oil Phase:
def OF(x):
    y = np.append(x, 0)
    #print("y = ",y)

    cs = CubicSpline(SWEXP, y, bc_type='natural', extrapolate=True)
    #cs = PchipInterpolator(SWEXP, y, extrapolate=True)
    DeltaP_Calc = np.zeros(Nfw)



    for i in range(Nfw):
        Sws_i = np.clip(Sws[:, i], SWEXP[0], SWEXP[-1])
        #print(Sws_i)
        #exit()
        kr_vals = cs(Sws_i)

        #print(i, " ===== ", fw[i], " ===== ", SWEXP[i], " ===== ",y[i])
        # Check for invalid kr values
        if np.any(kr_vals <= 0) or np.any(np.isnan(kr_vals)):
            #print("ERROR: Invalid kr_vals (<=0 or NaN) detected. Applying heavy penalty.")
            return 1.0e20  # Heavy penalty

        DeltaP_Calc[i] = muOil * (1 - fw[i]) * qt / K * np.sum(1 / kr_vals) * Delta_x + IncludeGravity * rhoOil * g * L

    # Enforce monotonic decrease in kro
    #print(DeltaP_Calc)
    #print(DeltaP)
    #exit()
    myPenalty = np.any((y[1:] - y[:-1]) > 0)
    return np.linalg.norm((DeltaP_Calc / LNew - DeltaP[:-1]) / DeltaP[:-1], ord=1) + 1.0e16 * myPenalty

def OF0(x):
	y=np.append(x,0)
	cs = CubicSpline(SWEXP, y, bc_type='natural',extrapolate = True)
	DeltaP_Calc = np.zeros(Nfw)
	for i in range(Nfw):
		DeltaP_Calc[i]=muOil*(1-fw[i])*qt/K*np.sum(1/cs(Sws[:,i]))*Delta_x+IncludeGravity*rhoOil*g*L
	myPenalty = np.sum(x[1:]-x[:-1]<0)
	return np.linalg.norm((DeltaP_Calc/LNew-DeltaP[:-1])/DeltaP[:-1],ord=1)+1.0e16*myPenalty

# Average Relative Error in Pressure Difference for Water Phase:	
def OFWater(x):
	y=np.insert(x,0,0.0001)

	y[-1]=1.0

	#exit()

	#print("SWEXP_N shape:", np.shape(SWEXP_N))
	#print("y shape:", np.shape(y))

	#cs = CubicSpline(SWEXP, y, bc_type='natural',extrapolate = True)
	
	cs = PchipInterpolator(SWEXP, y, extrapolate=True)

	#cs = interp1d(SWEXP, y,kind = 'quadratic',fill_value='extrapolate')

	DeltaP_Calc = np.zeros(Nfw)
	for i in range(Nfw):
		# Check for invalid kr values
		kr_vals = cs(Sws[:,i])
		#print(i, " ===== ", fw[i], " ===== ", SWEXP[i], " ===== ",y[i])
		
		if np.any(kr_vals <= 0) or np.any(np.isnan(kr_vals)):
			return 1.0e20  # Heavy penalty
		DeltaP_Calc[i]=muWater*(fw[i])*qt/K*np.sum(1/cs(Sws[:,i]))*Delta_x+IncludeGravity*rhoWater*g*L+PcInlet[i]-PcOutlet[i]

	myPenalty = np.sum(y[1:]-y[:-1]<0)
	return np.linalg.norm((DeltaP_Calc/LNew-DeltaP[1:])/DeltaP[1:],ord=1)+1.0e16*myPenalty
	
plotCounter = 0

b1 = (0,1)
b2 = (1,6)
bnds = (b1,b2)

Swplot = np.linspace(Swi,1-SoR,100)

# kro Based on assuming a homogenous saturation profile for each fw:
krO0 = np.array([0.023611111,	0.011893204,	0.003720871,	0.002560976,	0.002229299,	0.001902174,	1.0e-15])
#krO0 = 10.0*krO0
x0=krO0[:-1]

OFCriteriaOil =  (OF(x0))
print(OFCriteriaOil)

# Bounds & Constrants:

def constraint1(x):
	return 	x[0]-x[1]
def constraint2(x):
	return 	x[1]-x[2]
def constraint3(x):
	return 	x[2]-x[3]
def constraint4(x):
	return 	x[3]-x[4]
def constraint5(x):
	return 	x[4]-x[5]
def constraint6(x):
	return 	x[5]-x[6]

print("IG = ",x0)
print(OF(x0))

b1 = (0,1)

bnds = (b1,b1,b1,b1,b1,b1)
con1 = {'type':'ineq','fun':constraint1}
con2 = {'type':'ineq','fun':constraint2}
con3 = {'type':'ineq','fun':constraint3}
con4 = {'type':'ineq','fun':constraint4}
con5 = {'type':'ineq','fun':constraint5}
con6 = {'type':'ineq','fun':constraint6}
cons=[con1,con2,con3,con4,con5]


print("##################################################################")

# Number of Realisation:
nPlot = 100

global AllKrOil, AllKrWater,OF_Oil,OF_Water,nRunOil

AllKrOil= np.zeros((len(SWEXP)+1,nPlot))
OF_Oil = np.zeros(nPlot)

# krw Based on assuming a homogenous saturation profile for each fw:


krw0 = np.array([0.0555,	0.1359,	0.182,	0.23902439,	0.356687898,	0.684782609,	1.0])

x0=krw0[1:]

AllKrWater= np.zeros((len(SWEXP)+1,nPlot))
OF_Water = np.zeros(nPlot)
nRunOil = 0

# Oil Objective function minimizer:

def myMinimizer(i):

    print(i)

    plotCounter=0
    while(plotCounter<1):
        mySeed = np.random.randint(i*1e6, (i+1)*1e6)

        sol= differential_evolution(OF, bounds=bnds,maxiter=5000,seed=mySeed)   
        
        if(OF(sol.x)<OFCriteriaOil):
            print("mySeed = ", mySeed)
            krOil = np.append(sol.x,0)

            cs = PchipInterpolator(SWEXP, krOil)
            krOil[:-1] = cs(SWEXPMean)             
            print("krOil = ", krOil,"OFOil = ", OF(sol.x ))

            OF_Oil[i]     = OF(sol.x)
            plt.plot(SWEXP ,krOil,color = 'silver')
            
            return np.append(krOil,OF(sol.x))

# Water Objective function minimizer:

OFCriteriaW = OFWater(x0)

def myMinimizerW(i):
    print(i)

    plotCounter=0
    while(plotCounter<1):

        mySeed = np.random.randint(i*1e6, (i+1)*1e6)

        sol= differential_evolution(OFWater, bounds=bnds,maxiter=5000,seed=mySeed)
        #print(sol.x)
        #exit()

        if(OFWater(sol.x)<OFCriteriaW):
            krWater = np.insert(sol.x,0,0.00001)
            cs = PchipInterpolator(SWEXP, krWater)
            krWater[1:] = cs(SWEXPMean)
            print("krWater = ", krWater,"OFWater = ", OFWater(sol.x ))

            OF_Water[i]     = OFWater(sol.x)
            plt.plot(SWEXP ,krWater,color = 'silver')

            return np.append(krWater,OFWater(sol.x))

# Parallel Optimization:

print("Number of processors: ", multiprocessing.cpu_count())

num_cores = 50 # multiprocessing.cpu_count()

if __name__ == "__main__":
    AllKrOil = Parallel(n_jobs=num_cores)(delayed(myMinimizer)(i) for i in range(nPlot))

np.savetxt("AllKrOil.txt",np.transpose(AllKrOil))

if __name__ == "__main__":
    AllKrWater = Parallel(n_jobs=num_cores)(delayed(myMinimizerW)(i) for i in range(nPlot))    

np.savetxt("AllKrWater.txt",np.transpose(AllKrWater))




