import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import random
import os

import matplotlib
import os

plt.rcParams['font.family'] = 'DeJavu Serif'
plt.rcParams['font.serif'] = ['Times New Roman']
matplotlib.rcParams.update({'font.size': 14})




inSwExpMax = np.array([0.40176,	0.5648541,	0.61008,	0.7250745,	0.856437,	0.92442,	1])
inSwExpMax = np.array([0.46224,	0.6498859,	0.70192,	0.8342255,	0.985363,	1.0 	,	1])



inSwExpMin = np.array([1, 0.92442, 0.856437, 0.7250745, 0.61008, 0.5648541, 0.40176, 0.28083768])

#inkrWExpMax =np.array([0,	0.0442299509,	0.0729332242,	0.048413257,	0.0517566285,	0.0765499182,		0.5212831424])
#inkrWExpMin = np.array([0,	0.0147700491,	0.0074667758,	0.002586743,	0.0288433715,	0.0274500818,		0.4067168576])

#inkrOExpMax = np.array([0.9244697218,	0.4135499182,	0.2615531915,	0.0644099836,	0.0484833061,	0.0295833061,		0])
#inkrOExpMin = np.array([0.7575302782,	0.3644500818,	0.1764468085,	0.0545900164,	0.0321166939,	0.0132166939,		0])




krW = np.array([0.0555,	0.1359,	0.182,	0.23902439,	0.356687898,	0.684782609,	1.0])
krO = np.array([0.023611111,	0.011893204,	0.003720871,	0.002560976,	0.002229299,	0.001902174,	1.0e-15])

inkrWExpMax =1.01  *krW
inkrWExpMin =0.99 *krW

inkrOExpMax  =1.01 *krO
inkrOExpMin  =0.99 *krO

a = (pd.read_excel('WWBen_newSw2.xlsx'))
#a = (pd.read_excel('test.xlsx'))
Sws = a.to_numpy()

plt.figure(1)

SWEXPMean = np.array([1.00E+00,	9.95E-01,	9.21E-01,	7.80E-01,	6.56E-01,	6.07E-01,	4.32E-01])#np.mean(Sws,axis=0)
SWEXPMean = SWEXPMean[::-1]
inSwExpMax  =1.01*SWEXPMean
inSwExpMin  =0.99*SWEXPMean
print("===============================================")
print(inSwExpMax)
print(SWEXPMean)
print(inSwExpMin)
print("===============================================")


AllKrOil = np.transpose(np.loadtxt("AllKrOil.txt"))
AllKrOil=AllKrOil[AllKrOil[:,0]<0.5,:] 
AllKrOil=AllKrOil[:,:-1]

AllKrWater = np.transpose(np.loadtxt("AllKrWater.txt"))
AllKrWater = AllKrWater[AllKrWater[:,-2]>0.5,:] 
AllKrWater=AllKrWater[:,:-1]

kroMean = np.mean(AllKrOil,axis=0)
kroMax= np.amax(AllKrOil,axis=0)
kroMin= np.amin(AllKrOil,axis=0)
krwMean = np.mean(AllKrWater,axis=0)
krwMax= np.amax(AllKrWater,axis=0)
krwMin= np.amin(AllKrWater,axis=0)
plt.fill_between(SWEXPMean,kroMax,kroMin,color = 'r',alpha=0.2,label='_nolegend_')

print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
print("SWEXPMean",SWEXPMean[:-1])
print("kroMax :",kroMax[:-1])
print("kroMin :",kroMin[:-1])
print("kroMean :",kroMean[:-1])
print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
print("SWEXPMean",SWEXPMean[:-1])
print("krwMax :",krwMax[:-1])
print("krwMin :",krwMin[:-1])
print("krwMean :",krwMean[:-1])
print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
plt.plot(SWEXPMean,kroMax,color = 'r',alpha=0.2,label='_nolegend_')
plt.plot(SWEXPMean,kroMin,color = 'r',alpha=0.2,label='_nolegend_')
plt.plot(SWEXPMean,kroMean,':r+',label = "Mean of realisations (Oil)")

plt.fill_between(SWEXPMean,krwMax,krwMin,color = 'b',alpha=0.2,label='_nolegend_')
plt.plot(SWEXPMean,krwMax,color = 'b',alpha=0.35,label='_nolegend_')
plt.plot(SWEXPMean,krwMin,color = 'b',alpha=0.35,label='_nolegend_')
plt.plot(SWEXPMean,krwMean,':bx',label = "Mean of realisations (Water)")

plt.plot(SWEXPMean,krO,'ro', label = "Uniform (Oil)",linestyle='dashed')
plt.plot(SWEXPMean,krW,'bs', label = "Uniform (Water)",linestyle='dashed')

#yO_error = [krO - inkrOExpMin, inkrOExpMax - krO]
#yW_error = [krW - inkrWExpMin, inkrWExpMax - krW]



yO_error = [krO - inkrOExpMin, inkrOExpMax - krO]
yW_error = [krW - inkrWExpMin, inkrWExpMax - krW]

x_error = [SWEXPMean - inSwExpMin, inSwExpMax - SWEXPMean]


print("===============================================")
print(inSwExpMax)
print(SWEXPMean)
print(inSwExpMin)
print("===============================================")

plt.errorbar(SWEXPMean,krO, yerr=yO_error, xerr=x_error, fmt='ro', capsize=3)
plt.errorbar(SWEXPMean,krW, yerr=yW_error, xerr=x_error, fmt='bs', capsize=3)


#plt.fill(np.append(inSwExpMin, inSwExpMax[::-1]),np.append(inkrOExpMin, inkrOExpMax[::-1]),color = 'r',alpha=0.15,label='_nolegend_',hatch="+++")
#plt.fill(np.append(inSwExpMax, inSwExpMin[::-1]),np.append(inkrWExpMin, inkrWExpMax[::-1]),color = 'b',alpha=0.15,label='_nolegend_',hatch="xxx")

plt.legend()
m,n=np.shape(AllKrOil)
m,n=np.shape(AllKrWater)

plt.xlabel('$S_w$')
plt.ylabel('$k_r$')


ax = plt.gca()  # gca stands for 'get current axis'
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
ax.xaxis.set_ticks_position('bottom')
ax.spines['bottom'].set_position(('data',0))
ax.yaxis.set_ticks_position('left')
ax.spines['left'].set_position(('data',0))
plt.xlim(0, 1)
plt.ylim(0, 1)
#ax.set_xlabel('$S_w$', ontname="Arial", size=16,fontweight="bold")
#ax.set_ylabel('$k_r$', fontname="Arial", size=16,fontweight="bold")
ax.set_xlabel('$S_w$',  size=16,fontweight="bold")#, family='Arial')
ax.set_ylabel('$k_r$',  size=16,fontweight="bold")#, family='Arial')
#rc('font',**{'family':'serif','serif':['Times']})
#rc('text', usetex=True)

name = "Fig1"

if os.path.exists(name+".png"):
	os.remove(name+".png")        
plt.savefig(name+".png",dpi=100,bbox_inches='tight')
if os.path.exists(name+".eps"):
	os.remove(name+".eps")        
plt.savefig(name+".eps",format='eps',bbox_inches='tight')
#plt.show()
#exit()
'''
plt.figure(20)
yO_error = [krO - inkrOExpMin, inkrOExpMax - krO]
yW_error = [krW - inkrWExpMin, inkrWExpMax - krW]
x_error = [SWEXPMean - inSwExpMin, inSwExpMax - SWEXPMean]
plt.errorbar(SWEXPMean,krO, yerr=yO_error, xerr=x_error, fmt='rx')
#plt.errorbar(SWEXPMean,krW, yerr=yW_error, xerr=x_error, fmt='b+')
'''
#exit()
Lower_yValue = 1e-3

plt.figure(2)
plt.fill_between(SWEXPMean,kroMax,kroMin,color = 'r',alpha=0.2,label='_nolegend_')

plt.plot(SWEXPMean,kroMax,color = 'r',alpha=0.2,label='_nolegend_')
plt.plot(SWEXPMean,kroMin,color = 'r',alpha=0.2,label='_nolegend_')
plt.plot(SWEXPMean,kroMean,':r+',label = "Mean of realisations (Oil)")

plt.fill_between(SWEXPMean,krwMax,krwMin,color = 'b',alpha=0.2,label='_nolegend_')
plt.plot(SWEXPMean,krwMax,color = 'b',alpha=0.2,label='_nolegend_')
plt.plot(SWEXPMean,krwMin,color = 'b',alpha=0.2,label='_nolegend_')
plt.plot(SWEXPMean,krwMean,':bx',label = "Mean of realisations (Water)")


plt.plot(SWEXPMean,krO,'ro', label = "Uniform (Oil)",linestyle='dashed')
plt.plot(SWEXPMean,krW,'bs', label = "Uniform (Water)",linestyle='dashed')

yO_error = [krO - inkrOExpMin, inkrOExpMax - krO]
yW_error = [krW - inkrWExpMin, inkrWExpMax - krW]
xO_error = [SWEXPMean - inSwExpMin, inSwExpMax - SWEXPMean]
xW_error = [SWEXPMean - inSwExpMin, inSwExpMax - SWEXPMean]
plt.errorbar(SWEXPMean,krO, yerr=yO_error, xerr=xO_error, fmt='ro')
plt.errorbar(SWEXPMean,krW, yerr=yW_error, xerr=xW_error, fmt='bs')
'''
myX1 = inSwExpMin[:-1]
myX2 = inSwExpMax[:-1]
myY1 = inkrOExpMin[:-1]
myY2 = inkrOExpMax[:-1]
plt.fill(np.append(myX1, myX2[::-1]),np.append(myY1, myY2[::-1]),color = 'r',alpha=0.15,label='_nolegend_',hatch="+++")

myX1 = inSwExpMin[1:]
myX2 = inSwExpMax[1:]
myY1 = inkrWExpMin[1:]
myY2 = inkrWExpMax[1:]
plt.fill(np.append(myX2, myX1[::-1]),np.append(myY1, myY2[::-1]),color = 'b',alpha=0.15,label='_nolegend_',hatch="xxx")
'''
plt.legend()
m,n=np.shape(AllKrOil)
m,n=np.shape(AllKrWater)

plt.xlabel('$S_w$')
plt.ylabel('$k_r$')
ax.set_xlabel('$S_w$', fontname="Times New Roman", size=16,fontweight="bold")
ax.set_ylabel('$k_r$', fontname="Times New Roman", size=16,fontweight="bold")
plt.yscale('log')


plt.xlim(0, 1)
plt.ylim(Lower_yValue, 1)

ax = plt.gca()  # gca stands for 'get current axis'
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
ax.xaxis.set_ticks_position('bottom')
ax.spines['bottom'].set_position(('data',Lower_yValue))
#ax.yaxis.set_ticks_position('left')
#ax.spines['left'].set_position(('data',0))
#plt.axis([0, 1, 1e-3, 1])



name = "Fig2"


if os.path.exists(name+".png"):
	os.remove(name+".png")        
plt.savefig(name+".png",dpi=100,bbox_inches='tight')

if os.path.exists(name+".eps"):
	os.remove(name+".eps")        
	
plt.savefig(name+".eps",format='eps',bbox_inches='tight')
exit()
plt.figure(3)

#AllKrOil = (np.loadtxt("AllKrOil.txt"))
#AllKrWater = (np.loadtxt("AllKrWater.txt"))

def get_cmap(n, name='hsv'):
    '''Returns a function that maps each index in 0, 1, ..., n-1 to a distinct 
    RGB color; the keyword argument name must be a standard mpl colormap name.'''
    return plt.cm.get_cmap(name, n)
cmapO = get_cmap(m,'Paired')
cmapW = get_cmap(m,'Paired')
alphaValue = 1.0
myLineWidth = 1.5


plt.plot(SWEXPMean,AllKrOil,color = (1,0,0),alpha=alphaValue,linewidth=myLineWidth,linestyle='dashed',  label='Oil')
plt.plot(SWEXPMean,AllKrWater,color = (0,0,1),alpha=alphaValue,linewidth=myLineWidth,linestyle='dashed',  label='Water')    
for ii in range(1,m):
    rgb = (1,0,0)#cmapO(50)#(random.random(), random.random(), random.random())
    plt.plot(SWEXPMean,AllKrOil[ii,:-1],color = rgb,alpha=alphaValue,linewidth=myLineWidth,linestyle='dashed', label='_nolegend_')
    rgb = (0,0,1)#cmapW(50)
    plt.plot(SWEXPMean,AllKrWater[ii,:-1],color = rgb,alpha=alphaValue,linewidth=myLineWidth,linestyle='dashed', label='_nolegend_')    
ax = plt.gca()  # gca stands for 'get current axis'
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
ax.xaxis.set_ticks_position('bottom')
ax.spines['bottom'].set_position(('data',0))
ax.yaxis.set_ticks_position('left')
ax.spines['left'].set_position(('data',0))
plt.xlim(0, 1)
plt.ylim(0, 1)
ax.set_xlabel('$S_w$', fontname="Times New Roman", size=16,fontweight="bold")
ax.set_ylabel('$k_r$', fontname="Times New Roman", size=16,fontweight="bold")
plt.plot(SWEXPMean[:-1],krO[:-1],'-r', label = "Uniform (Oil)")
plt.plot(SWEXPMean[1:],krW[1:],'-b', label = "Uniform (Water)")

yO_error = [krO[:-1] - inkrOExpMin[:-1], inkrOExpMax[:-1] - krO[:-1]]
yW_error = [krW[1:] - inkrWExpMin[1:], inkrWExpMax[1:] - krW[1:]]
xO_error = [SWEXPMean[:-1] - inSwExpMin[:-1], inSwExpMax[:-1] - SWEXPMean[:-1]]
xW_error = [SWEXPMean[1:] - inSwExpMin[1:], inSwExpMax[1:] - SWEXPMean[1:]]
plt.errorbar(SWEXPMean[:-1],krO[:-1], yerr=yO_error, xerr=xO_error, fmt=':ro')
plt.errorbar(SWEXPMean[1:],krW[1:], yerr=yW_error, xerr=xW_error, fmt=':bs')
plt.legend()
name = "Fig3"

if os.path.exists(name+".png"):
	os.remove(name+".png")        
plt.savefig(name+".png",dpi=100,bbox_inches='tight')
if os.path.exists(name+".eps"):
	os.remove(name+".eps")        
plt.savefig(name+".eps",format='eps',bbox_inches='tight')
plt.figure(4)

plt.plot(SWEXPMean[:-1],AllKrOil[0,:-2],color = (1,0,0),alpha=alphaValue,linewidth=myLineWidth,linestyle='dashed', label='Oil')
plt.plot(SWEXPMean[1:],AllKrWater[0,1:-1],color = (0,0,1),alpha=alphaValue,linewidth=myLineWidth,linestyle='dashed',  label='Water')    
for ii in range(1,m):
    rgb = (1,0,0)#cmapO(50)#(random.random(), random.random(), random.random())
    plt.plot(SWEXPMean[:-1],AllKrOil[ii,:-2],color = rgb,alpha=alphaValue,linewidth=myLineWidth,linestyle='dashed', label='_nolegend_')
    rgb = (0,0,1)#cmapW(50)#
    plt.plot(SWEXPMean[1:],AllKrWater[ii,1:-1],color = rgb,alpha=alphaValue,linewidth=myLineWidth,linestyle='dashed', label='_nolegend_')    
ax = plt.gca()  # gca stands for 'get current axis'
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
ax.xaxis.set_ticks_position('bottom')
ax.spines['bottom'].set_position(('data',Lower_yValue))
ax.yaxis.set_ticks_position('left')
ax.spines['left'].set_position(('data',0))
plt.xlim(0, 1)
plt.ylim(Lower_yValue, 1)
ax.set_xlabel('$S_w$', fontname="Times New Roman", size=16,fontweight="bold")
ax.set_ylabel('$k_r$', fontname="Times New Roman", size=16,fontweight="bold")
plt.plot(SWEXPMean[:-1],krO[:-1],'-r', label = "Uniform (Oil)")
plt.plot(SWEXPMean[1:],krW[1:],'-b', label = "Uniform (Water)")

yO_error = [krO[:-1] - inkrOExpMin[:-1], inkrOExpMax[:-1] - krO[:-1]]
yW_error = [krW[1:] - inkrWExpMin[1:], inkrWExpMax[1:] - krW[1:]]
xO_error = [SWEXPMean[:-1] - inSwExpMin[:-1], inSwExpMax[:-1] - SWEXPMean[:-1]]
xW_error = [SWEXPMean[1:] - inSwExpMin[1:], inSwExpMax[1:] - SWEXPMean[1:]]
plt.errorbar(SWEXPMean[:-1],krO[:-1], yerr=yO_error, xerr=xO_error, fmt=':ro')
plt.errorbar(SWEXPMean[1:],krW[1:], yerr=yW_error, xerr=xW_error, fmt=':bs')
plt.yscale('log')
plt.legend()

plt.gca().spines['top'].set_visible(False)  
plt.gca().spines['right'].set_visible(False)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.rcParams['axes.labelsize'] = 16
plt.rcParams['axes.titlesize'] = 16
#'''
name = "Fig4"

if os.path.exists(name+".png"):
	os.remove(name+".png")        
plt.savefig(name+".png",dpi=100,bbox_inches='tight')
if os.path.exists(name+".eps"):
	os.remove(name+".eps")        
plt.savefig(name+".eps",format='eps',bbox_inches='tight')

#'''
plt.show()
